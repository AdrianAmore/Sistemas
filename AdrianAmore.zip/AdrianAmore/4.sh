#!/bin/bash
echo "Introduce un valor mayor que 0"
read valor
while [ $valor -le 0 ]
do
	echo "El valor introducido no es correcto, introducelo de nuevo."
	read valor
done
for i in `seq 0 $valor`
do
	echo "$i"
done
