#!/bin/bash
echo "Introduce el valor 1: "
read valor1 
echo "Introduce el valor 2: "
read valor2
if [ $valor1 -gt $valor2 ]
then
	echo "El valor 1 es el mayor"
else
	if [ $valor1 -lt $valor2 ]
	then
		echo "El valor 2 es mayor"
else
	if [ $valor1 -eq $valor2 ]
	then
		echo "Los valores son iguales"
fi
read -p "Continuar..."