#!/bin/bash
echo "Introduce un dia del 1 al 30"
read dia
while [[ $dia -lt 1 || $dia -gt 30 ]]
do
	echo "El valor introducido no es valido, introduce uno nuevo"
	read dia
done
if [[ $dia -eq 1 || $dia -eq 8 || $dia -eq 15 || $dia -eq 22 || $dia -eq 29 ]]
then
	echo "El dia introducido corresponde al Lunes"
fi
if [[ $dia -eq 2 || $dia -eq 9 || $dia -eq 16 || $dia -eq 23 || $dia -eq 30 ]]
then
	echo "El dia introducido corresponde al Martes"
fi
if [[ $dia -eq 3 || $dia -eq 10 || $dia -eq 17 || $dia -eq 24 ]]
then
	echo "El dia introducido corresponde al Miercoles"
fi
if [[ $dia -eq 4 || $dia -eq 11 || $dia -eq 18|| $dia -eq 25 ]]
then
	echo "El dia introducido corresponde al Jueves"
fi
if [[ $dia -eq 5 || $dia -eq 12 || $dia -eq 19 || $dia -eq 26 ]]
then
	echo "El dia introducido corresponde al Viernes"
fi
if [[ $dia -eq 6 || $dia -eq 13 || $dia -eq 20 || $dia -eq 27 ]]
then
	echo "El dia introducido corresponde al Sabado"
fi
if [[ $dia -eq 7 || $dia -eq 14 || $dia -eq 21 || $dia -eq 28 ]]
then
	echo "El dia introducido corresponde al Domingo"
fi


