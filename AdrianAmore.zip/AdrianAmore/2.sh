#!/bin/bash
echo "Introduce un numero mayor que 0"
read variable
while [ $variable -le 0 ]
do
	echo "El valor introducido no es valido, introduce un nuevo valor:"
	read variable
done
resto=$(($variable%2))
if [ $resto -eq 0 ]
then
	echo "El numero introducido es par."
else
	echo "El numero introducido es impar."
fi
