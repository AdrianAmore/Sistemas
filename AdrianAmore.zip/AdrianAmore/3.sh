#!/bin/bash
echo " dime la nota de tu examen:"
read nota
while [[ $nota -lt 0 || $nota -gt 10 ]]
do
	echo "El valor que has introducido no es correcto, introduce uno nuevo:"
	read nota
done
if [ $nota -le 4 ]
then
	echo "Has suspendido"
fi
if [ $nota -eq 5 ]
then
	echo "Tienes un suficiente"
fi
if [ $nota -eq 6 ]
then
	echo "Tienes un bien" 
fi
if [ $nota -gt 6 && $nota -le 8 ]
then
	echo "Tienes un notable"
fi
if [ $nota -gt 9 ]
then
	echo "Tienes un sobresaliente"
fi
read -p "Continuar"